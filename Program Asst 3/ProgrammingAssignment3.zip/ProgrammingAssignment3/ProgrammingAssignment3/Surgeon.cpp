//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#include "Doctor.h"
#include "Surgeon.h"
#include <string>

using namespace std;

//----------------
// initialize member variable in this class
//----------------
Surgeon::Surgeon()
	:Doctor(), operating('Y') {}

//----------------
// set operating to desired operating
//----------------
void Surgeon::setOperating(char ope)
{
    operating = ope;
}

//----------------
// return the operating
//----------------
char Surgeon::getOperating()
{
    return operating;
}

//----------------
// return a line of description consists of ID, name and specialty and operating
//----------------
string Surgeon::toString()
{
    return Doctor::toString()+" Operating: "+operating;
}

//---------------------
// return true if otherSurgeon is equal to this surgeon
//---------------------
bool Surgeon::equals (Surgeon otherSurgeon)
{
	return ((Doctor::equals(otherSurgeon)) && (operating == otherSurgeon.operating));
}