//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#ifndef CONTROLLER_H
#define CONTROLLER_H
#include "HospitalSystem.h"
#include <iostream>

using namespace std;

class Controller
{
private:
	HospitalSystem system;		//track access to class HospitalSystem

public:
	void UCLoadEmployee();
	void UCAddEmployee();
	void UCDeleteEmployee();
	void UCDisplayEmployee();
	void UCSaveEmployee();
};

#endif