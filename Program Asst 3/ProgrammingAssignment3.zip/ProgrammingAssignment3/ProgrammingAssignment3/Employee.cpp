//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#include "Employee.h"
#include <string>

using namespace std;

//---------------------
// initialize name and ID and role
//---------------------
Employee::Employee()
	:name ("any"), ID ("any"), role('A') {}

//---------------------
// mutator method sets name 
//---------------------
void Employee::setName(string aName)
{
	name = aName;
}

//---------------------
// mutator method sets ID
//---------------------
void Employee::setID(string anID)
{
    ID = anID;
}

//---------------------
// mutator method sets role
//---------------------
void Employee::setRole(char aRole)
{
    role = aRole;
}

//---------------------
// accessor methods returns name
//---------------------
string Employee::getName()
{
    return name;
}

//---------------------
// accessor methods returns ID
//---------------------
string Employee::getID()
{
    return ID;
}

//---------------------
// accessor methods returns role
//---------------------
char Employee::getRole()
{
    return role;
}

//---------------------
// return a line of name and ID
//---------------------
string Employee::toString()
{
    return ("Name: "+ name +" Number: "+ ID);
}

//---------------------
// return true if otherEmployee is equal to this employee
//---------------------
bool Employee::equals(Employee otherEmployee)
{
	return ((name == otherEmployee.name) && (ID == otherEmployee.ID) && (role == otherEmployee.role));
}
