//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#ifndef NURSE_H
#define NURSE_H
#include "Employee.h"
#include <string>
#include <iostream>

using namespace std;

class Nurse: public Employee
{
private: 
	string numPatient;		//track number of patients of a nurse

public:
	Nurse();
	void setNumPatient(string num);
	string getNumPatient();
	string toString();
	bool equals (Nurse otherNurse);
};

#endif

