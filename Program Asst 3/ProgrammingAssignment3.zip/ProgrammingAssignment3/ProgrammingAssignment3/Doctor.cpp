//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#include "Doctor.h"
#include "Employee.h"
#include <string>

using namespace std;

//-----------------
// initialize member variable in this class
//-----------------
Doctor::Doctor()
	: Employee(), specialty("any") {}

//---------------
// set specialty to desired specialty
//---------------
void Doctor::setSpecialty(string spec)
{
    specialty = spec;
}

//---------------
// return the specialty
//---------------
string Doctor::getSpecialty()
{
    return specialty;
}

//---------------
// return a line of description consists of ID, name and specialty
//---------------
string Doctor::toString()
{
    return (Employee::toString()) + " Specialty: " + specialty;
}

//---------------------
//return true if otherDoctor is equal to this doctor
//---------------------
bool Doctor::equals (Doctor otherDoctor)
{
	return ((Employee::equals(otherDoctor)) && (specialty == otherDoctor.specialty));
}