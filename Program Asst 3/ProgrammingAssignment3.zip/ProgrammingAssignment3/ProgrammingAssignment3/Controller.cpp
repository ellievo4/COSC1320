//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#include "Controller.h"
#include "HospitalSystem.h"
#include <iostream>

using namespace std;

//This is for loading employee information
void Controller::UCLoadEmployee()
{
	system.loadEmployee();
}
//connect between user option and system operation. This is for adding an employee
void Controller::UCAddEmployee()
{
    system.addEmployee();
}

//connect between user option and system operation. This is for deleting an employee
void Controller::UCDeleteEmployee()
{
    system.deleteEmployee();
}

//connect between user option and system operation. This is for displaying employees
void Controller::UCDisplayEmployee()
{
    system.displayEmployee();
}

//This is for saving employee information
void Controller::UCSaveEmployee()
{
    system.saveEmployee();
}

