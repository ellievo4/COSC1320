//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#ifndef RECEPTIONIST_H
#define RECEPTIONIST_H
#include "Administrator.h"
#include <string>

using namespace std;

class Receptionist: public Administrator
{
private:
	char answering;		//track answering status of a receptionist

public:
	Receptionist();
	void setAnswering(char ans);
	char getAnswering();
	string toString();
	bool equals (Receptionist otherRecep);
};

#endif