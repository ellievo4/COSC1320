//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#ifndef ADMINISTRATOR_H
#define ADMINISTRATOR_H
#include "Employee.h"
#include <string>

using namespace std;

class Administrator: public Employee
{
private:
	string department;		//track department of an administrator

public:
	Administrator();
	void setDepartment(string dep);
	string getDepartment();
	string toString();
	bool equals (Administrator otherAdmin);
};

#endif