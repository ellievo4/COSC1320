//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#ifndef DOCTOR_H
#define DOCTOR_H
#include <string>
#include "Employee.h"

using namespace std;


class Doctor: public Employee
{
private: 
	string specialty;		//track specialty of a doctor

public:
	Doctor();
	void setSpecialty(string spec);
	string getSpecialty();
	string toString();
	bool equals (Doctor otherDoctor);
};

#endif