//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#include <iostream>
#include <string>
#include "Employee.h"
#include "Doctor.h"
#include "Surgeon.h"
#include "Nurse.h"
#include "Administrator.h"
#include "Janitor.h"
#include "Receptionist.h"
#include "HospitalSystem.h"
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

//----------------------------------
// initial all member variables of this class
//----------------------------------
HospitalSystem::HospitalSystem()
{
	for (int i = 0; i < 5; i++)
       {
           emp[i] = Employee();
           dr[i] = Doctor();
           sn[i] = Surgeon();
           ne[i] = Nurse();
           admin[i] = Administrator();
           recep[i] = Receptionist();
           jan[i] = Janitor();
       }

	for (int i = 0; i < 8; i++)
		counter[i] = 0;
}


//----------------------------------
// load the employee information from the text file
//----------------------------------
void HospitalSystem::loadEmployee()
{
	char role;													//track role
	string name;												//track name
	string ID;													//track ID
	string specialty;											//track specialty
	char operating;												//track operating
	string numPatient;											//track numPatient
	string department;											//track department
	char sweeping;												//track sweeping
	char answering;												//track answering
	ifstream inFile("Programming Assignment 3 Data.txt");		//track the stream input data

	//make sure the file is opened
	if(inFile.fail()) 
	{
		cout << "fail to open file" << endl;
	}

	// open file and stream in the first character
	cout << "File is now open" << endl;
	inFile >> role;
		
	while(!inFile.eof())
	{
		    //match the first letter which is the role with appropriate classification, in example, d for doctor
            //set the rest of the line streamed in into arrays of information for each employee
            switch(role)
            {
               //employee name and ID
               case 'h':
                   emp[counter[0]].setRole(role);
				   inFile >> name;
                   emp[counter[0]].setName(name);
				   inFile >> ID;
                   emp[counter[0]].setID(ID);
                   counter[0]++;
                   break;

               //doctor name, ID and specialty
               case 'd':
                   dr[counter[1]].setRole(role);
				   inFile >> name;
                   dr[counter[1]].setName(name);
				   inFile >> ID;
                   dr[counter[1]].setID(ID);
				   inFile >> specialty;
                   dr[counter[1]].setSpecialty(specialty);
                   counter[1]++;
                   break;

               //surgeon name, ID, specialty and operating
               case 's':
                   sn[counter[2]].setRole(role);
				   inFile >> name;
                   sn[counter[2]].setName(name);
				   inFile >> ID;
                   sn[counter[2]].setID(ID);
				   inFile >> specialty;
                   sn[counter[2]].setSpecialty(specialty);
				   inFile >> operating;
                   sn[counter[2]].setOperating(operating);
                   counter[2]++;
                   break;

               //nurse name, ID and number of patient
               case 'n':
                   ne[counter[3]].setRole(role);
				   inFile >> name;
                   ne[counter[3]].setName(name);
				   inFile >> ID;
                   ne[counter[3]].setID(ID);
				   inFile >> numPatient;
                   ne[counter[3]].setNumPatient(numPatient);
                   counter[3]++;
                   break;

               //administrator name, ID and department
               case 'a':
                   admin[counter[4]].setRole(role);
				   inFile >> name;
                   admin[counter[4]].setName(name);
				   inFile >> ID;
                   admin[counter[4]].setID(ID);
				   inFile >> department;
                   admin[counter[4]].setDepartment(department);
                   counter[4]++;
                   break;

               //janitor name, ID, department and sweeping
               case 'j':
                   jan[counter[5]].setRole(role);
                   inFile >> name;
                   jan[counter[5]].setName(name);
				   inFile >> ID;
                   jan[counter[5]].setID(ID);
				   inFile >> department;
                   jan[counter[5]].setDepartment(department);
				   inFile >> sweeping;
                   jan[counter[5]].setSweeping(sweeping);
                   counter[5]++;
                   break;

               //receptionist name, ID, department and answering
               case 'r':
                   recep[counter[6]].setRole(role);
                    inFile >> name;
                   recep[counter[6]].setName(name);
				   inFile >> ID;
                   recep[counter[6]].setID(ID);
				   inFile >> department;
                   recep[counter[6]].setDepartment(department);
				   inFile >> answering;
                   recep[counter[6]].setAnswering(answering);
                   counter[6]++;
                   break;
            }

            //count all employees
            counter[7]++;

			//stream in another role
			inFile >> role;
	}

	//close file
	inFile.close();
}


//----------------------------------
// add one or more employee
//----------------------------------
void HospitalSystem::addEmployee()
{
	char role;				//track role
	string name;			//track name
	string ID;				//track ID
	string specialty;		//track specialty
	char operating;			//track operating
	string numPatient;		//track numPatient
	string department;		//track department
	char sweeping;			//track sweeping
	char answering;			//track answering
	bool done = false;		//track the exit of the while loop

	//show an introduction for the role typed in
    cout << "\nYou choose ADD option\n" << endl;
    cout << "Please enter a letter following the instruction below: " << endl;
    cout << "\'h\' for Employee." << endl;
    cout << "\'d\' for Doctor." << endl;
    cout << "\'s\' for Surgeon." << endl;
    cout << "\'n\' for Nurse." << endl;
    cout << "\'a\' for Administrator." << endl;
    cout << "\'j\' for Janitor." << endl;
    cout << "\'r\' for Receptionist." << endl;
    cout << "\'e\' or \'E\' to Exit this option." << endl;
       
	while(!done)
    {
		//require input
        cout << "\n>>>> Your input: ";

        //input the letter represented role
        cin >> role;

        // match the role with appropriate classification so that user can input
        // enough correct information
        switch(role)
        {
			//for employee
			case 'h':
                   emp[counter[0]].setRole(role);
                   cout << "\nPlease enter name of the employee:\n" << "> ";
                   cin >> name;
				   emp[counter[0]].setName(name);
                   cout << "\nPlease enter ID of the employee:\n" << "> ";
				   cin >> ID;
                   emp[counter[0]].setID(ID);
                   counter[0]++;
                   break;

			//for doctor
			case 'd':
                   dr[counter[1]].setRole(role);
                   cout << "\nPlease enter name of the doctor:\n" << "> ";
                   cin >> name;
				   dr[counter[1]].setName(name);
                   cout << "\nPlease enter ID of the doctor:\n" << "> ";
				   cin >> ID;
                   dr[counter[1]].setID(ID);
                   cout << "\nPlease enter specialty of the doctor:\n" << "> ";
				   cin >> specialty;
                   dr[counter[1]].setSpecialty(specialty);
                   counter[1]++;
                   break;

			//for surgeon
		    case 's':
                   sn[counter[2]].setRole(role);
                   cout << "\nPlease enter name of the surgeon:\n" << "> ";
                   cin >> name;
				   sn[counter[2]].setName(name);
                   cout << "\nPlease enter ID of the surgeon:\n" << "> ";
				   cin >> ID;
                   sn[counter[2]].setID(ID);
                   cout << "\nPlease enter specialty of the surgeon:\n" << "> ";
				   cin >> specialty;
                   sn[counter[2]].setSpecialty(specialty);
                   cout << "\nPlease enter operating of the surgeon (Y/N):\n" << "> ";
				   cin >> operating;
                   sn[counter[2]].setOperating(operating);
                   counter[2]++;
                   break;

			//for nurse
            case 'n':
                   ne[counter[3]].setRole(role);
                   cout << "\nPlease enter name of the nurse:\n" << "> ";
				   cin >> name;
                   ne[counter[3]].setName(name);
                   cout << "\nPlease enter ID of the nurse:\n" << "> ";
				   cin >> ID;
                   ne[counter[3]].setID(ID);
                   cout << "\nPlease enter number of patients of the nurse:\n" << "> ";
				   cin >> numPatient;
                   ne[counter[3]].setNumPatient(numPatient);
                   counter[3]++;
                   break;

			//for administrator
			case 'a':
                   admin[counter[4]].setRole(role);
                   cout << "\nPlease enter name of the administrator:\n" << "> ";
				   cin >> name;
                   admin[counter[4]].setName(name);
                   cout << "\nPlease enter ID of the administrator:\n" << "> ";
				   cin >> ID;
                   admin[counter[4]].setID(ID);
                   cout << "\nPlease enter department of the adminitrator:\n" << "> ";
				   cin >> department;
                   admin[counter[4]].setDepartment(department);
                   counter[4]++;
                   break;

			//for janitor
			case 'j':
                   jan[counter[5]].setRole(role);
                   cout << "\nPlease enter name of the janitor:\n" << "> ";
				   cin >> name;
                   jan[counter[5]].setName(name);
                   cout << "\nPlease enter ID of the janitor:\n" << "> ";
				   cin >> ID;
                   jan[counter[5]].setID(ID);
                   cout << "\nPlease enter department of the janitor:\n" << "> ";
				   cin >> department;
                   jan[counter[5]].setDepartment(department);
                   cout << "\nPlease enter sweeping of the janitor (Y/N):\n" << "> ";
				   cin >> sweeping;
                   jan[counter[5]].setSweeping(sweeping);
                   counter[5]++;
                   break;

			//for receptionist
			case 'r':
                   recep[counter[6]].setRole(role);
                   cout << "\nPlease enter name of the receptionist:\n" << "> ";
				   cin >> name;
                   recep[counter[6]].setName(name);
                   cout << "\nPlease enter ID of the receptionist:\n" << "> ";
				   cin >> ID;
                   recep[counter[6]].setID(ID);
                   cout << "\nPlease enter department of the receptionist:\n" << "> ";
				   cin >> department;
                   recep[counter[6]].setDepartment(department);
                   cout << "\nPlease enter answering of the receptionist (Y/N):\n" << "> ";
				   cin >> answering;
                   recep[counter[6]].setAnswering(answering);
                   counter[6]++;
                   break;

			//for exit option
			case 'e':
			case 'E': 
                   cout << "Exit ADD Option!!!" << endl;
                   done = true;
                   continue;

			//other inputs are considered invalid
			default: cout << "Invalid input!!!" << endl; continue;
		}

           //keep track with total number of employee
           counter[7]++;
	}
}


//----------------------------------
// delete one or more employee
//----------------------------------
void HospitalSystem::deleteEmployee()
{
	char role;					//track role of employee
	string name;				//track name of employee
	bool done = false;          //track the while loop prompting user input information
    int foundIndex = 0;			//track the position of the user input String in array
	int i;                      //track all indexes of arrays

	//show an introduction for the role typed in
    cout << "\nYou choose DELETE option\n" << endl;
    cout << "Please enter a letter following the instruction below: " << endl;
    cout << "\'h\' for Employee." << endl;
    cout << "\'d\' for Doctor." << endl;
    cout << "\'s\' for Surgeon." << endl;
    cout << "\'n\' for Nurse." << endl;
    cout << "\'a\' for Administrator." << endl;
    cout << "\'j\' for Janitor." << endl;
    cout << "\'r\' for Receptionist." << endl;
    cout << "\'e\' or \'E\' to Exit this option." << endl;

	while(!done)
	{
		//require input
        cout << "\n>>>> Your input: ";

        //input the letter represented role
        cin >> role;

        // match the role with appropriate classification so that user can input information that
        // needs to be deleted
        switch(role)
        {
			//search input name in the employee array then delete its information by shift other 
            // elements in the array up
            case 'h':
                   cout << "\nPlease enter name of the employee:\n" << "> ";
                   cin >> name;

                   for (i=0; i<counter[0]; i++)
                       if (emp[i].getName() == name) foundIndex = i;

                   for (i=foundIndex; i<(counter[0]-1); i++)
                       emp[i] = emp[i+1]; 
                   
				   counter[0]--;
				   cout << "Delete sucessfully!" << endl;
                   break;

            //search input name in the doctor array then delete its information by shift other elements in
            // the array up
            case 'd':
                   cout << "\nPlease enter name of the doctor to delete:\n" << "> ";
                   cin >> name;

                   for (i=0; i<counter[1]; i++)
                       if (dr[i].getName() == name) foundIndex = i;

                   for (i=foundIndex; i<(counter[1]-1); i++)
                       dr[i] = dr[i+1];
 
                   counter[1]--;
				   cout << "Delete sucessfully!" << endl;
                   break;

            //search input name in the surgeon array then delete its information by shift 
            // other elements in the array up
            case 's':
                   cout << "\nPlease enter name of the surgeon:\n" << "> ";
                   cin >> name;

                   for (i=0; i<counter[2]; i++)
                       if (sn[i].getName() == name) foundIndex = i;

                   for (i=foundIndex; i<(counter[2]-1); i++)
                       sn[i] = sn[i+1];

                   counter[2]--;
				   cout << "Delete sucessfully!" << endl;
                   break;

            //search input name in the nurse array then delete its information by shift other elements in
            // the array up
            case 'n':
                   cout << "\nPlease enter name of the nurse:\n" << "> ";
                   cin >> name;

                   for (i=0; i<counter[3]; i++)
                       if (ne[i].getName() == name) foundIndex = i;

                   for (i=foundIndex; i<counter[3]-1; i++)
                       ne[i] = ne[i+1];
                       
                   counter[3]--;
				   cout << "Delete sucessfully!" << endl;
                   break;

            //search input name in the administrator array then delete its information by
            // shift other elements in the array up
            case 'a':
                   cout << "\nPlease enter name of the administrator:\n" << "> ";
                   cin >> name;

                   for (i=0; i<counter[4]; i++)
                       if (admin[i].getName() == name) foundIndex = i;

                   for (i=foundIndex; i<(counter[4]-1); i++)
                       admin[i] = admin[i+1];

                   counter[4]--;
				   cout << "Delete sucessfully!" << endl;
                   break;

            //search input name in the janitor array then delete its information by
            // shift other elements in the array up
            case 'j':
                   cout << "\nPlease enter name of the janitor:\n" << "> ";
                   cin >> name;

                   for (i=0; i<counter[5]; i++)
                       if (jan[i].getName() == name) foundIndex = i;

                   for (i=foundIndex; i<(counter[5]-1); i++)
                       jan[i] = jan[i+1];

                   counter[5]--;
				   cout << "Delete sucessfully!" << endl;
                   break;

			//search input name in the receptionist array then delete its information by
			// shift other elements in the array up
			case 'r':
                    cout << "\nPlease enter name of the receptionist:\n" << "> ";
                    cin >> name;

                    for (i=0; i<counter[6]; i++)
                        if (recep[i].getName() == name) foundIndex = i;

                    for (i=foundIndex; i<(counter[6]-1); i++)
                        recep[i] = recep[i+1];
                       
                    counter[6]--;
				    cout << "Delete sucessfully!" << endl;
                    break;

			// exit the option
            case 'e':
            case 'E': cout << "Exit DELETE option!!!" << endl;
                   done = true;
                   continue;

			// other inputs are considered invalid
		    default: cout << "Invalid input!!!" << endl; continue;
		}

        //keep track with the total number of employee
        counter[7]--;
	}
}


//----------------------------------
// display a list of employee
//----------------------------------
void HospitalSystem::displayEmployee()
{
	int i;   //track indexes of all arrays

	// introduction
    cout << "\nYou choose DISPLAY option\n" << endl;
	cout << "The Hospital has the following employees:\n" << endl;

    // for employee
    cout << "Hospital Employees: " << counter[0] << endl;
    for (i = 0; i< counter[0]; i++)
		cout << emp[i].toString() << endl;

    // for doctor
    cout << "\nDoctors: " << counter[1] << endl;
    for (i = 0; i< counter[1]; i++)
        cout << dr[i].toString() << endl;

    // for surgeon
    cout << "\nSurgeons: " << counter[2] << endl;
    for (i = 0; i< counter[2]; i++)
        cout << sn[i].toString() << endl;

    // for nurse
    cout << "\nNurses: " << counter[3] << endl;
    for (i = 0; i< counter[3]; i++)
        cout << ne[i].toString() << endl;

    // for administrator
    cout << "\nAdministrators: " << counter[4] << endl;
    for (i = 0; i< counter[4]; i++)
        cout << admin[i].toString() << endl;

    // for receptionist
    cout << "\nReceptionists: " << counter[6] << endl;
    for (i = 0; i< counter[6]; i++)
        cout << recep[i].toString() << endl;

    // for janitor
    cout << "\nJanitors: " << counter[5] << endl;
    for (i = 0; i< counter[5]; i++)
		cout << jan[i].toString() << endl;

    // for total number of employees
        cout << "\nTotal number of Employees: " << counter[7] << endl;
}


//----------------------------------
// save information to text file
//----------------------------------
void HospitalSystem::saveEmployee()
{
	ofstream outFile ("output data.txt");		//track stream output data
	int i;										//track index

	//make sure file is opened, if not, exit the program
	if (outFile.fail())
	{	
		cout << "cannot open file" << endl;
		exit(0);
	}
	
		// output a notification
        cout << "Writing to the file!" << endl;

		// writing employee to file
       for (i=0; i<counter[0]; i++)
           outFile << emp[i].getRole() << " " << emp[i].getName() << " " << emp[i].getID() << endl;

       // writing doctor to file
       for (i=0; i<counter[1]; i++)
           outFile << dr[i].getRole() << " " << dr[i].getName() << " " << dr[i].getID()
                   << " " << dr[i].getSpecialty() << endl;

       // writing surgeon to file
       for (i=0; i<counter[2]; i++)
           outFile << sn[i].getRole() << " " << sn[i].getName() << " " << sn[i].getID()
                   << " " << sn[i].getSpecialty() << " " << sn[i].getOperating() << endl;

       // writing nurse to file
       for (i=0; i<counter[3]; i++)
           outFile << ne[i].getRole() << " " << ne[i].getName() << " " << ne[i].getID()
                   << " " << ne[i].getNumPatient() << endl;

       // writing administrator to file
       for (i=0; i<counter[4]; i++)
           outFile << admin[i].getRole() << " " << admin[i].getName() << " " << admin[i].getID()
                   << " " << admin[i].getDepartment() << endl;

       // writing janitor to file
       for (i=0; i<counter[5]; i++)
           outFile << jan[i].getRole() << " " << jan[i].getName() << " " << jan[i].getID()
                   << " " << jan[i].getDepartment() << " " << jan[i].getSweeping() << endl;

       // writing receptionist to file
       for (i=0; i<counter[6]; i++)
           outFile << recep[i].getRole() << " " + recep[i].getName() << " " << recep[i].getID()
                   << " " << recep[i].getDepartment() << " " << recep[i].getAnswering() << endl;
	
    // close the text file
    outFile.close();

    // output a good-bye line
    cout << "You choose to EXIT! Have a nice day!" << endl;
}



