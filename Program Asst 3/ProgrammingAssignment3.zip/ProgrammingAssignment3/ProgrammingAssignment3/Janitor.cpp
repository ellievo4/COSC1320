//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#include "Janitor.h"
#include "Administrator.h"
#include <string>

using namespace std;

//-------------------
// initialize member variable in this class
//-------------------
Janitor::Janitor()
	:Administrator(), sweeping('Y') {}

//-------------------
//set sweeping to desired sweeping
//-------------------
void Janitor::setSweeping(char sweep)
    {
        sweeping = sweep;
    }

//-------------------
//return the sweeping
//-------------------
char Janitor::getSweeping()
    {
        return sweeping;
    }

//-------------------
//return a line of description consists of ID, name and sweeping
//-------------------
string Janitor::toString()
    {
        return Administrator::toString()+" Sweeping: "+sweeping;
    }

//---------------------
// return true if otherJanitor is equal to this janitor
//---------------------
bool Janitor::equals(Janitor otherJanitor)
{
	return ((Administrator::equals(otherJanitor)) && (sweeping == otherJanitor.sweeping));
}