//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#include "Employee.h"
#include "Nurse.h"
#include <string>
#include <iostream>

using namespace std;

//-------------
// initialize member variable in this class
//-------------
Nurse::Nurse()
	: Employee(), numPatient("0") {}

//----------------------------------
//set number of patients to desired number of patient
//----------------------------------
void Nurse::setNumPatient(string num)
{
    numPatient = num;
}

//--------------------------
// return the numPatient
//--------------------------
string Nurse::getNumPatient()
{
    return numPatient;
}

//----------------------
// return a line of description consists of ID, name and numPatient
//----------------------
string Nurse::toString()
{
    return ((Employee::toString()) + (" Number of Patients: " + numPatient));
}

//---------------------
// return true if otherNurse is equal to this nurse
//---------------------
bool Nurse::equals (Nurse otherNurse)
{
	return ((Employee::equals(otherNurse)) && (numPatient == otherNurse.numPatient));
}