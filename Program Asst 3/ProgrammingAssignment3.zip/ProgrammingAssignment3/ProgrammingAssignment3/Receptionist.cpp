//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#include "Receptionist.h"
#include "Administrator.h"
#include <string>

using namespace std;

//----------------------------
//initialize member variable in this class
//----------------------------
Receptionist::Receptionist()
	: Administrator(), answering('Y') {}

//----------------------------
//set answering to desired answering
//----------------------------
void Receptionist::setAnswering(char ans)
{
    answering = ans;
}

//----------------------------
//return the answering
//----------------------------
char Receptionist::getAnswering()
{
    return answering;
}

//----------------------------
//return a line of description consists of ID, name and answering
//----------------------------
string Receptionist::toString()
{
    return Administrator::toString()+" Answering: "+ answering;
}

//---------------------
// return true if otherRecep is equal to this receptionist
//---------------------
bool Receptionist::equals(Receptionist otherRecep)
{
	return ((Administrator::equals(otherRecep)) && (answering == otherRecep.answering));
}