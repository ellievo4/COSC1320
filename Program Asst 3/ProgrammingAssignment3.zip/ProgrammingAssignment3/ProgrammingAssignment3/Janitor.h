//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#ifndef JANITOR_H
#define JANITOR_H
#include "Administrator.h"
#include <string>

using namespace std;

class Janitor: public Administrator
{
private: 
	char sweeping;		//track sweeping status of a janitor

public:
	Janitor();
	void setSweeping(char sweep);
	char getSweeping();
	string toString();
	bool equals (Janitor otherJanitor);
};

#endif

