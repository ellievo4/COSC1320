//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#ifndef SURGEON_H
#define SURGEON_H
#include "Doctor.h"
#include <string>

using namespace std;

class Surgeon: public Doctor
{
private:
	char operating;		//track operating status of a surgeon
	
public:
	Surgeon();
	void setOperating(char ope);
	char getOperating();
	string toString();
	bool equals (Surgeon otherSurgeon);
};

#endif