//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#ifndef HOSPITALSYSTEM_H
#define HOSPITALSYSTEM_H
#include <iostream>
#include <string>
#include "Employee.h"
#include "Doctor.h"
#include "Surgeon.h"
#include "Nurse.h"
#include "Administrator.h"
#include "Janitor.h"
#include "Receptionist.h"
#include <iostream>
#include <fstream>

using namespace std;

class HospitalSystem
{
private: 
	Employee emp[5];				//get access to class Employee
	Doctor dr[5];					//get access to class Doctor
	Surgeon sn[5];					//get access to class Surgeon
	Nurse ne[5];					//get access to class Nurse
	Administrator admin[5];			//get access to class Administrator
	Receptionist recep[5];			//get access to class Receptionist
	Janitor jan[5];					//get access to class Janitor
	int counter[8];					//track the counts for elements in each array and count for total employee

public:
	HospitalSystem();
	void loadEmployee();
	void addEmployee();
	void deleteEmployee();
	void displayEmployee();
	void saveEmployee();
};

#endif