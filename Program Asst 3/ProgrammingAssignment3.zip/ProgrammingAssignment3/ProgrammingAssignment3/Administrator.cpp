//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#include "Administrator.h"
#include "Employee.h"
#include <string>

using namespace std;

//-----------------------------------
//initialize member variable in this class
//-----------------------------------
Administrator::Administrator()
	: Employee(), department("any") {}

//-----------------------------------
//set department to desired department
//-----------------------------------
void Administrator::setDepartment(string dep)
{
    department = dep;
}

//-----------------------------------
// return the department
//-----------------------------------
string Administrator::getDepartment()
{
    return department;
}

//-----------------------------------
//return a line of description consists of ID, name and department
//-----------------------------------
string Administrator::toString()
{
    return Employee::toString()+" Department: "+department;
}

//---------------------
// return true if otherAdmin is equal to this administrator
//---------------------
bool Administrator::equals(Administrator otherAdmin)
{
	return ((Employee::equals(otherAdmin)) && (department == otherAdmin.department));
}