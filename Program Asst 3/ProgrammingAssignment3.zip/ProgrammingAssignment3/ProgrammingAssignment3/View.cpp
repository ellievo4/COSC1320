//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#include "View.h"
#include <iostream>

using namespace std;

//---------------------------------------------
// display the introduction of the application
//---------------------------------------------
void View::showSelection()
{
	cout << "\nWelcome to Our Hospital" << endl;
    cout << "What can I do for you today?" << endl;
    cout << "1. Add employee(s)" << endl;
    cout << "2. Delete employee(s)" << endl;
    cout << "3. Display the list of employees" << endl;
    cout << "4. Exit" << endl;
    cout << "\n >>"; 
}
	