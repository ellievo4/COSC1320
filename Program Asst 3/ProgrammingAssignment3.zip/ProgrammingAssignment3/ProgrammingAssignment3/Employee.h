//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 3
//This is my own work, I will not post

#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include <string>

using namespace std;

class Employee
{
private:
	string name;    // track name of an employee
	string ID;      // track ID of an employee
	char role;      // track the role of an employee

public:
	Employee();
	void setName(string aName);
	void setID(string anID);
	void setRole(char aRole);
	string getName();
	string getID();
	char getRole();
	string toString();
	bool equals(Employee otherEmployee);
};

#endif