//COSC 1320 Summer 2015
//Thanh Vo
//Program Assignment 2
//This is my own work, I will not post

package programassignment2;

//*********************************
//ProgramAssignment2.java
//*********************************
public class ProgramAssignment2
{    
    //------------------------------------
    //main method of the program
    //------------------------------------
    public static void main(String[] args)
    {
        //call View object and set GUI visible to user
        View gui = new View();
        gui.setVisible(true);
    }
}
