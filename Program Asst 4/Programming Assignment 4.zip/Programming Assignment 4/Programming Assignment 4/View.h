//COSC 1320 Summer 2015
//Thanh Vo
//Programming Assignment 4
//This is my own work, I will not post

#ifndef VIEW_H
#define VIEW_H
#include <iostream>
using namespace std;

class View
{
public:
	void showSelection();
};
#endif