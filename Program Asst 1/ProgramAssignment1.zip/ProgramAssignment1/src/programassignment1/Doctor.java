//COSC 1320 Summer 2015
//Thanh Vo
//Program Assignment 1
//This is my own work, I will not post

package programassignment1;


public class Doctor extends Employee
{
    private String specialty;       //track the specialty of the doctor

    // initialize instance variable in this class
    public Doctor()
    {
        super();
        specialty = "any";
    }

    // return a line of description consists of ID, name and specialty
    @Override
    public String toString()
    {
        return super.toString()+" Specialty: "+specialty;
    }

    //set specialty to desired specialty
    public void setSpecialty(String spec)
    {
        specialty = spec;
    }

    // return the specialty
    public String getSpecialty()
    {
        return specialty;
    }
}
