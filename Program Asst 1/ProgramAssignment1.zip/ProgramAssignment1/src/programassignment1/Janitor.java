//COSC 1320 Summer 2015
//Thanh Vo
//Program Assignment 1
//This is my own work, I will not post

package programassignment1;


public class Janitor extends Administrator
{
    private char sweeping;

    // initialize instance variable in this class
    public Janitor()
    {
        super();
        sweeping = 'A';
    }

    // return a line of description consists of ID, name and sweeping
    @Override
    public String toString()
    {
        return super.toString()+" Maintenance Sweeping: "+sweeping;
    }

    //set sweeping to desired sweeping
    public void setSweeping(char sweep)
    {
        sweeping = sweep;
    }

    // return the sweeping
    public char getSweeping()
    {
        return sweeping;
    }
}
