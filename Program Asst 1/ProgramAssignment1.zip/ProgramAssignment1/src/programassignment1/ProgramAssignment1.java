//COSC 1320 Summer 2015
//Thanh Vo
//Program Assignment 1
//This is my own work, I will not post

package programassignment1;
import java.util.Scanner;

public class ProgramAssignment1
{
    public static void main(String[] args)
    {
       Scanner keyboard = new Scanner(System.in);       //get access to class scanner to prompt input
       int option;                                      //track the option input from user
       View view = new View();                          //get access from class View
       Controller control = new Controller();           //get access from class Controller
       boolean done = false;                            //keep track of the exitting application

       control.UCLoad();

       while(!done)
       {
           //show introduction
           view.showSelection();

           //input an option from user
           option = keyboard.nextInt();

           //match input with the right option case
           switch(option)
           {
               case 1: control.UCAdd(); break;
               case 2: control.UCDelete(); break;
               case 3: control.UCDisplay(); break;
               case 4: control.UCSave(); done = true; break;
               default: System.out.println("Invalid Input!!!");
           }
        }
    }
}
