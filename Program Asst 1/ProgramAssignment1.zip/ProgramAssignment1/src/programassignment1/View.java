//COSC 1320 Summer 2015
//Thanh Vo
//Program Assignment 1
//This is my own work, I will not post

package programassignment1;


public class View
{
    
    /* display the introduction of the application*/
    public void showSelection()
    {
        System.out.println("\nWelcome to Our Hospital");
        System.out.println("What can I do for you today?");
        System.out.println("1. Add employee(s)");
        System.out.println("2. Delete employee(s)");
        System.out.println("3. Display the list of employees");
        System.out.println("4. Exit");
        System.out.print("\n >>");
    }
}
