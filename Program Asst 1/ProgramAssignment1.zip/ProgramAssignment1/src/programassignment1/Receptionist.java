//COSC 1320 Summer 2015
//Thanh Vo
//Program Assignment 1
//This is my own work, I will not post

package programassignment1;


public class Receptionist extends Administrator
{
    private char answering;

    // initialize instance variable in this class
    public Receptionist()
    {
        super();
        answering = 'Y';
    }

    // return a line of description consists of ID, name and answering
    @Override
    public String toString()
    {
        return super.toString()+" Answering: "+ answering;
    }

    //set answering to desired answering
    public void setAnswering(char ans)
    {
        answering = ans;
    }

    // return the answering
    public char getAnswering()
    {
        return answering;
    }
}
