//COSC 1320 Summer 2015
//Thanh Vo
//Program Assignment 1
//This is my own work, I will not post


package programassignment1;


public class Administrator extends Employee
{
    private String department;

    // initialize instance variable in this class
    public Administrator()
    {
        super();
        department = "any";
    }

    // return a line of description consists of ID, name and department
    @Override
    public String toString()
    {
        return super.toString()+" Department: "+department;
    }

    //set department to desired department
    public void setDepartment(String dep)
    {
        department = dep;
    }

    // return the department
    public String getDepartment()
    {
        return department;
    }
}
