//COSC 1320 Summer 2015
//Thanh Vo
//Program Assignment 1
//This is my own work, I will not post

package programassignment1;


public class Surgeon extends Doctor
{
    private char operating;

    // initialize instance variable in this class
    public Surgeon()
    {
        super();
        operating = 'Y';
    }

    // return a line of description consists of ID, name and specialty and operating
    @Override
    public String toString()
    {
        return super.toString()+" Operating: "+operating;
    }

    //set operating to desired operating
    public void setOperating(char ope)
    {
        operating = ope;
    }

    // return the operating
    public char getOperating()
    {
        return operating;
    }
}
