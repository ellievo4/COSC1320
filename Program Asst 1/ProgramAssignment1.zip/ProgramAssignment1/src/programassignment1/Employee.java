//COSC 1320 Summer 2015
//Thanh Vo
//Program Assignment 1
//This is my own work, I will not post

package programassignment1;


public class Employee
{
    private String name;    // track name of an employee
    private String ID;      // track ID of an employee
    private char role;      // track the role of employee

    // initialize name and ID
    public Employee(){
        name = "any";
        ID = "any";
    }

    // return a line of name and ID
    @Override
    public String toString(){
        return ("Name: "+name+" Number: "+ID);
    }

    // mutator method sets name 
    public void setName(String aName)
    {
        name = aName;
    }

    // mutator method sets ID
    public void setID(String anID)
    {
        ID = anID;
    }

    // mutator method sets role
    public void setRole(char aRole)
    {
        role = aRole;
    }

    // accessor methods returns name
    public String getName()
    {
        return name;
    }

    // accessor methods returns ID
    public String getID()
    {
        return ID;
    }

    // accessor methods returns role
    public char getRole()
    {
        return role;
    }
}
