//COSC 1320 Summer 2015
//Thanh Vo
//Program Assignment 1
//This is my own work, I will not post

package programassignment1;

import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.FileOutputStream;

public class HospitalSystem
{
   private Employee[] emp = new Employee[5];
   private Doctor[] dr = new Doctor[5];
   private Surgeon[] sn = new Surgeon[5];
   private Nurse[] ne = new Nurse[5];
   private Administrator[] admin = new Administrator[5];
   private Receptionist[] recep = new Receptionist[5];
   private Janitor[] jan = new Janitor[5];
   private int [] counter = new int[8];



   //initial all instance variables of this class
   public HospitalSystem()
   {
       for (int i = 0; i < 5; i++)
       {
           emp[i] = new Employee();
           dr[i] = new Doctor();
           sn[i] = new Surgeon();
           ne[i] = new Nurse();
           admin[i] = new Administrator();
           recep[i] = new Receptionist();
           jan[i] = new Janitor();
           counter[i] = 0;
       }

   }



   // load the employee information from the text file
   public void load() 
   {
       char role = 'A';             //track the role streamed in
       Scanner inFile = null;       //track the stream in from text file

       // try-block and catch-block to make sure the file is opened
       try
       {
            inFile = new Scanner(new FileInputStream("Programming Assignment 1 Data.txt"));
       }
       catch (FileNotFoundException e)
       {
            System.out.println("Text file was not found");
            System.out.println("or could not be opened.");
            System.exit(0);
       }

       // scan through the file until reaching the end of the file
       while(inFile.hasNext())
       {
           //stream in the first letter of a line
           role = inFile.next().charAt(0);

           //match the first letter which is the role with appropriate classification, in example, d for doctor
           //set the rest of the line streamed in into arrays of information for each employee
           switch(role)
           {
               //employee name and ID
               case 'h':
                   emp[counter[0]].setRole(role);
                   emp[counter[0]].setName(inFile.next());
                   emp[counter[0]].setID(inFile.next());
                   counter[0]++;
                   break;

               //doctor name, ID and specialty
               case 'd':
                   dr[counter[1]].setRole(role);
                   dr[counter[1]].setName(inFile.next());
                   dr[counter[1]].setID(inFile.next());
                   dr[counter[1]].setSpecialty(inFile.next());
                   counter[1]++;
                   break;

               //surgeon name, ID, specialty and operating
               case 's':
                   sn[counter[2]].setRole(role);
                   sn[counter[2]].setName(inFile.next());
                   sn[counter[2]].setID(inFile.next());
                   sn[counter[2]].setSpecialty(inFile.next());
                   sn[counter[2]].setOperating(inFile.next().charAt(0));
                   counter[2]++;
                   break;

               //nurse name, ID and number of patient
               case 'n':
                   ne[counter[3]].setRole(role);
                   ne[counter[3]].setName(inFile.next());
                   ne[counter[3]].setID(inFile.next());
                   ne[counter[3]].setNumPatient(inFile.nextInt());
                   counter[3]++;
                   break;

               //administrator name, ID and department
               case 'a':
                   admin[counter[4]].setRole(role);
                   admin[counter[4]].setName(inFile.next());
                   admin[counter[4]].setID(inFile.next());
                   admin[counter[4]].setDepartment(inFile.next());
                   counter[4]++;
                   break;

               //janitor name, ID, department and sweeping
               case 'j':
                   jan[counter[5]].setRole(role);
                   jan[counter[5]].setName(inFile.next());
                   jan[counter[5]].setID(inFile.next());
                   jan[counter[5]].setDepartment(inFile.next());
                   jan[counter[5]].setSweeping(inFile.next().charAt(0));
                   counter[5]++;
                   break;

               //receptionist name, ID, department and answering
               case 'r':
                   recep[counter[6]].setRole(role);
                   recep[counter[6]].setName(inFile.next());
                   recep[counter[6]].setID(inFile.next());
                   recep[counter[6]].setDepartment(inFile.next());
                   recep[counter[6]].setAnswering(inFile.next().charAt(0));
                   counter[6]++;
                   break;
           }

           //count all employees
           counter[7]++;
       }

       //close the text file
       inFile.close();
   }



   // add more employee
   public void add()
   {
       Scanner keyboard = new Scanner(System.in);       //track the input of user
       char role = 'A';                                 //track the role input
       boolean done = false;                            //track the while loop prompting user input information

       //show an introduction for the role typed in
       System.out.println("\nYou choose ADD option\n");
       System.out.println("Please enter a letter following the instruction below: ");
       System.out.println("\'h\' for Employee.");
       System.out.println("\'d\' for Doctor.");
       System.out.println("\'s\' for Surgeon.");
       System.out.println("\'n\' for Nurse.");
       System.out.println("\'a\' for Administrator.");
       System.out.println("\'j\' for Janitor.");
       System.out.println("\'r\' for Receptionist.");
       System.out.println("\'e\' or \'E\' to Exit this option.");
       
       while(!done)
       {
           //require input
           System.out.print("\n>>>> Your input: ");

           //input the letter represented role
           role = keyboard.next().charAt(0);

           // match the role with appropriate classification so that user can input
           // enough correct information
           switch(role)
           {
               case 'h':
                   emp[counter[0]].setRole(role);
                   System.out.print("\nPlease enter name of the employee:\n" + "> ");
                   emp[counter[0]].setName(keyboard.next());
                   System.out.print("\nPlease enter ID of the employee:\n" + "> ");
                   emp[counter[0]].setID(keyboard.next());
                   counter[0]++;
                   break;

               case 'd':
                   dr[counter[1]].setRole(role);
                   System.out.print("\nPlease enter name of the doctor:\n" + "> ");
                   dr[counter[1]].setName(keyboard.next());
                   System.out.print("\nPlease enter ID of the doctor:\n" + "> ");
                   dr[counter[1]].setID(keyboard.next());
                   System.out.print("\nPlease enter specialty of the doctor:\n" + "> ");
                   dr[counter[1]].setSpecialty(keyboard.next());
                   counter[1]++;
                   break;

               case 's':
                   sn[counter[2]].setRole(role);
                   System.out.print("\nPlease enter name of the surgeon:\n" + "> ");
                   sn[counter[2]].setName(keyboard.next());
                   System.out.print("\nPlease enter ID of the surgeon:\n" + "> ");
                   sn[counter[2]].setID(keyboard.next());
                   System.out.print("\nPlease enter specialty of the surgeon:\n" + "> ");
                   sn[counter[2]].setSpecialty(keyboard.next());
                   System.out.print("\nPlease enter operating of the surgeon:\n" + "> ");
                   sn[counter[2]].setOperating(keyboard.next().charAt(0));
                   counter[2]++;
                   break;

               case 'n':
                   ne[counter[3]].setRole(role);
                   System.out.print("\nPlease enter name of the nurse:\n" + "> ");
                   ne[counter[3]].setName(keyboard.next());
                   System.out.print("\nPlease enter ID of the nurse:\n" + "> ");
                   ne[counter[3]].setID(keyboard.next());
                   System.out.print("\nPlease enter number of patients of the nurse:\n" + "> ");
                   ne[counter[3]].setNumPatient(keyboard.nextInt());
                   counter[3]++;
                   break;

               case 'a':
                   admin[counter[4]].setRole(role);
                   System.out.print("\nPlease enter name of the administrator:\n" + "> ");
                   admin[counter[4]].setName(keyboard.next());
                   System.out.print("\nPlease enter ID of the administrator:\n" + "> ");
                   admin[counter[4]].setID(keyboard.next());
                   System.out.print("\nPlease enter department of the adminitrator:\n" + "> ");
                   admin[counter[4]].setDepartment(keyboard.next());
                   counter[4]++;
                   break;

               case 'j':
                   jan[counter[5]].setRole(role);
                   System.out.print("\nPlease enter name of the janitor:\n" + "> ");
                   jan[counter[5]].setName(keyboard.next());
                   System.out.print("\nPlease enter ID of the janitor:\n" + "> ");
                   jan[counter[5]].setID(keyboard.next());
                   System.out.print("\nPlease enter department of the janitor:\n" + "> ");
                   jan[counter[5]].setDepartment(keyboard.next());
                   System.out.print("\nPlease enter sweeping of the janitor:\n" + "> ");
                   jan[counter[5]].setSweeping(keyboard.next().charAt(0));
                   counter[5]++;
                   break;

               case 'r':
                   recep[counter[6]].setRole(role);
                   System.out.print("\nPlease enter name of the receptionist:\n" + "> ");
                   recep[counter[6]].setName(keyboard.next());
                   System.out.print("\nPlease enter ID of the receptionist:\n" + "> ");
                   recep[counter[6]].setID(keyboard.next());
                   System.out.print("\nPlease enter department of the receptionist:\n" + "> ");
                   recep[counter[6]].setDepartment(keyboard.next());
                   System.out.print("\nPlease enter answering of the receptionist:\n" + "> ");
                   recep[counter[6]].setAnswering(keyboard.next().charAt(0));
                   counter[6]++;
                   break;

               case 'e':
               case 'E': 
                   System.out.println("Exit ADD Option!!!");
                   done = true;
                   continue;

               default: System.out.println("Invalid input!!!");
           }

           //keep track with total number of employee
           counter[7]++;
       }
   }



   // delete one employee
   public void delete()
   {
       char role = 'A';                                 //track the letter enterred for role
       Scanner keyboard = new Scanner(System.in);       //track the input from user
       boolean done = false;                            //track the while loop prompting user input information
       int foundIndex = 0;                              //track the position of the user input String in array
       int i;                                           //track all indexes of arrays
       String name = new String();                      //track the name input by user

       //show an introduction for the role typed in
       System.out.println("\nYou choose DELETE option\n");
       System.out.println("Please enter a letter following the instruction below: ");
       System.out.println("\'h\' for Employee.");
       System.out.println("\'d\' for Doctor.");
       System.out.println("\'s\' for Surgeon.");
       System.out.println("\'n\' for Nurse.");
       System.out.println("\'a\' for Administrator.");
       System.out.println("\'j\' for Janitor.");
       System.out.println("\'r\' for Receptionist.");
       System.out.println("\'e\' or \'E\' to Exit this option.");

       while(!done)
       {
           //require input
           System.out.print("\n>>>> Your input: ");

           //input the letter represented role
           role = keyboard.next().charAt(0);

           // match the role with appropriate classification so that user can input information that
           // needs to be deleted
           switch(role)
           {
               //search input name in the employee array then delete its information by shift other 
               // elements in the array up
               case 'h':
                   System.out.print("\nPlease enter name of the employee:\n" + "> ");
                   name = keyboard.next();

                   for (i=0; i<counter[0]; i++)
                       if ((emp[i].getName()).equals(name)) foundIndex = i;

                   for (i=foundIndex; i<(counter[0]-1); i++)
                       emp[i] = emp[i+1];
                       
                   emp[counter[0]-1] = null;
                   counter[0]--;
                   break;

               //search input name in the doctor array then delete its information by shift other elements in
               // the array up
               case 'd':
                   System.out.print("\nPlease enter name of the doctor:\n" + "> ");
                   name = keyboard.next();

                   for (i=0; i<counter[1]; i++)
                       if ((dr[i].getName()).equals(name)) foundIndex = i;

                   for (i=foundIndex; i<(counter[1]-1); i++)
                       dr[i] = dr[i+1];

                   dr[counter[1]-1] = null;
                   counter[1]--;
                   break;

               //search input name in the surgeon array then delete its information by shift 
               // other elements in the array up
               case 's':
                   System.out.print("\nPlease enter name of the surgeon:\n" + "> ");
                   name = keyboard.next();

                   for (i=0; i<counter[2]; i++)
                       if ((sn[i].getName()).equals(name)) foundIndex = i;

                   for (i=foundIndex; i<(counter[2]-1); i++)
                       sn[i] = sn[i+1];

                   sn[counter[2]-1] = null;
                   counter[2]--;
                   break;

               //search input name in the nurse array then delete its information by shift other elements in
               // the array up
               case 'n':
                   System.out.print("\nPlease enter name of the nurse:\n" + "> ");
                   name = keyboard.next();

                   for (i=0; i<counter[3]; i++)
                       if ((ne[i].getName()).equals(name)) foundIndex = i;

                   for (i=foundIndex; i<counter[3]-1; i++)
                       ne[i] = ne[i+1];
                       
                   ne[counter[3]-1] = null;
                   counter[3]--;
                   break;

               //search input name in the administrator array then delete its information by
               // shift other elements in the array up
               case 'a':
                   System.out.print("\nPlease enter name of the administrator:\n" + "> ");
                   name = keyboard.next();

                   for (i=0; i<counter[4]; i++)
                       if ((admin[i].getName()).equals(name)) foundIndex = i;

                   for (i=foundIndex; i<(counter[4]-1); i++)
                       admin[i] = admin[i+1];

                   admin[counter[4]-1] = null;
                   counter[4]--;
                   break;

               //search input name in the janitor array then delete its information by
               // shift other elements in the array up
               case 'j':
                   System.out.print("\nPlease enter name of the janitor:\n" + "> ");
                   name = keyboard.next();

                   for (i=0; i<counter[5]; i++)
                       if ((jan[i].getName()).equals(name)) foundIndex = i;

                   for (i=foundIndex; i<(counter[5]-1); i++)
                       jan[i] = jan[i+1];

                   jan[counter[5]-1] = null;
                   counter[5]--;
                   break;

               //search input name in the receptionist array then delete its information by
               // shift other elements in the array up
               case 'r':
                   System.out.print("\nPlease enter name of the receptionist:\n" + "> ");
                   name = keyboard.next();

                   for (i=0; i<counter[6]; i++)
                       if ((recep[i].getName()).equals(name)) foundIndex = i;

                   for (i=foundIndex; i<(counter[6]-1); i++)
                       recep[i] = recep[i+1];
                       
                   recep[counter[6]-1] = null;
                   counter[6]--;
                   break;

               // exit the option
               case 'e':
               case 'E': System.out.println("Exit DELETE option!!!");
                   done = true;
                   continue;

               // other inputs are considered invalid
               default: System.out.println("Invalid input!!!");
           }

           //keep track with the total number of employee
           counter[7]--;
       }
    }



   // display a list of employee
   public void display()
   {
       int i;   //track indexes of all arrays

       // introduction
       System.out.println("\nYou choose DISPLAY option\n");
       System.out.println("The Hospital has the following employees:\n");

       // for employee
       System.out.println("Hospital Employees: " + counter[0]);
       for (i = 0; i< counter[0]; i++)
           System.out.println(emp[i].toString());

       // for doctor
       System.out.println("\nDoctors: " + counter[1]);
       for (i = 0; i< counter[1]; i++)
           System.out.println(dr[i].toString());

       // for surgeon
       System.out.println("\nSurgeons: " + counter[2]);
       for (i = 0; i< counter[2]; i++)
           System.out.println(sn[i].toString());

       // for nurse
       System.out.println("\nNurses: " + counter[3]);
       for (i = 0; i< counter[3]; i++)
           System.out.println(ne[i].toString());

       // for administrator
       System.out.println("\nAdministrators: " + counter[4]);
       for (i = 0; i< counter[4]; i++)
           System.out.println(admin[i].toString());

        // for receptionist
       System.out.println("\nReceptionists: " + counter[6]);
       for (i = 0; i< counter[6]; i++)
           System.out.println(recep[i].toString());

       // for janitor
       System.out.println("\nJanitors: " + counter[5]);
       for (i = 0; i< counter[5]; i++)
           System.out.println(jan[i].toString());

      // for total number of employees
       System.out.println("\nTotal number of Employees: " + counter[7]);
   }



   // save information to text file
   public void save()
   {
       PrintWriter outFile = null;      //track the stream output to text file
       int i;                           // track all indexes of arrays

       // try-block and catch-block to make sure the file is opened
       try
       {
            outFile = new PrintWriter(new FileOutputStream("Data.txt"));
       }
       catch (FileNotFoundException e)
       {
            System.out.println("text file was not found");
            System.out.println("or could not be opened.");
            System.exit(0);
       }
       
       // output a notification
       System.out.println("Writing to the file!");

       // writing employee to file
       for (i=0; i<counter[0]; i++)
           outFile.println(emp[i].getRole() + " " + emp[i].getName() + " " + emp[i].getID());

       // writing doctor to file
       for (i=0; i<counter[1]; i++)
           outFile.println(dr[i].getRole() + " " + dr[i].getName() + " " + dr[i].getID()
                   + " " + dr[i].getSpecialty());

       // writing surgeon to file
       for (i=0; i<counter[2]; i++)
           outFile.println(sn[i].getRole() + " " + sn[i].getName() + " " + sn[i].getID()
                   + " " + sn[i].getSpecialty() + " " + sn[i].getOperating());

       // writing nurse to file
       for (i=0; i<counter[3]; i++)
           outFile.println(ne[i].getRole() + " " + ne[i].getName() + " " + ne[i].getID()
                   + " " + ne[i].getNumPatient());

       // writing administrator to file
       for (i=0; i<counter[4]; i++)
           outFile.println(admin[i].getRole() + " " + admin[i].getName() + " " + admin[i].getID()
                   + " " + admin[i].getDepartment());

       // writing janitor to file
       for (i=0; i<counter[5]; i++)
           outFile.println(jan[i].getRole() + " " + jan[i].getName() + " " + jan[i].getID()
                   + " " + jan[i].getDepartment() + " " + jan[i].getSweeping());

       // writing receptionist to file
       for (i=0; i<counter[6]; i++)
           outFile.println(recep[i].getRole() + " " + recep[i].getName() + " " + recep[i].getID()
                   + " " + recep[i].getDepartment() + " " + recep[i].getAnswering());

       // close the text file
       outFile.close();

       // output a good-bye line
       System.out.println("You choose to EXIT! Have a nice day!");
   }
}
