//COSC 1320 Summer 2015
//Thanh Vo
//Program Assignment 1
//This is my own work, I will not post

package programassignment1;


public class Controller
{
    private HospitalSystem system = new HospitalSystem();

    //This is for loading employee information
    public void UCLoad()
    {
        system.load();
    }
    //connect between user option and system operation. This is for adding an employee
    public void UCAdd()
    {
        system.add();
    }

    //connect between user option and system operation. This is for deleting an employee
    public void UCDelete()
    {
        system.delete();
    }

    //connect between user option and system operation. This is for displaying employees
    public void UCDisplay()
    {
        system.display();
    }

    //This is for saving employee information
    public void UCSave()
    {
        system.save();
    }
}
