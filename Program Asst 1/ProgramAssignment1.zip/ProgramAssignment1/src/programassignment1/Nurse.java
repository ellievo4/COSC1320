//COSC 1320 Summer 2015
//Thanh Vo
//Program Assignment 1
//This is my own work, I will not post

package programassignment1;


public class Nurse extends Employee
{
    private int numPatient;

    // initialize instance variable in this class
    public Nurse()
    {
        super();
        numPatient = 0;
    }

    // return a line of description consists of ID, name and numPatient
    @Override
    public String toString()
    {
        return super.toString()+" Number of Patients: "+numPatient;
    }

    //set number of patients to desired number of patient
    public void setNumPatient(int num)
    {
        numPatient = num;
    }

    // return the numPatient
    public int getNumPatient()
    {
        return numPatient;
    }
}
